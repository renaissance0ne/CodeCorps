import React ,{ useState } from 'react';
import { Routes, Route,Navigate} from 'react-router-dom';
import { Layout } from './layout/Layout';
import { Home } from './home/Home';
import Login from './Components/Login';
import LEADERBOARDS from './Components/LEADERBOARDS';
import Logout from './Components/Logout';
import { ABOUT } from './ABOUT/ABOUT';
import {COURSES} from './COURSES/COURSES';
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  return (    
      <Routes>
      <Route path="/" element={<Login  setIsAuthenticated={setIsAuthenticated}/>} />
        <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated}/>} />
        <Route path="/LEADERBOARDS" element={isAuthenticated?<Layout><LEADERBOARDS /></Layout>:<Navigate to="/login" />} />
        <Route path="/logout" element={isAuthenticated?<Layout><Logout /></Layout>:<Navigate to="/login" />}/>
        
        <Route path="/home" element={isAuthenticated?<Layout><Home /></Layout>:<Navigate to="/login" />} />
        <Route path="/ABOUT" element={isAuthenticated?<Layout><ABOUT/></Layout>:<Navigate to="/login" />} />       
        <Route path="/COURSES" element={isAuthenticated?<Layout><COURSES/></Layout>:<Navigate to="/login" />} />       
          
      </Routes>
    
  );
}
 
export default App;

