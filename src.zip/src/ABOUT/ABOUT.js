import React, { Component } from 'react';

export class ABOUT extends Component {
    // static displayName = Test.name;

    constructor(props) {
        super(props);
        this.state = { currentCount: 0 };
        this.incrementCounter = this.incrementCounter.bind(this);
    }

    incrementCounter() {
        this.setState({
            currentCount: this.state.currentCount + 1
        });
    }

    render() {
        const containerStyle = {
            backgroundColor: '#CBC3E3', // Use your preferred background color code here
        };

        return (
            <div style={containerStyle}>
                <h2>ABOUT</h2>
                <div className="row">
                    <div className="col-lg-6">
                        <p className="lead">CodeCorps could be a platform that encourages programmers to code in a fun and collaborative environment, with a mascot resembling a cat to add a touch of creativity. The platform hosts coding challenges, provide educational content, and foster a community where programmers, or "CodeCorps," can share their love for coding and technology.</p>
                    </div>
                    <div className="col-lg-6 text-lg-end">
                        <img src={`${process.env.PUBLIC_URL}/assets/images/paw.png`} alt="" className="d-none d-lg-inline" />
                    </div>
                </div>

                <h2>WHY CHOOSE THIS PLATFORM?</h2>
                <div className="row">
                    <div className="col-lg-6">
                        <p className="lead"><p>The Simultaneous Algorithm Creator caters to individuals, especially beginners in programming, who often dive into solving code problems without initial planning or the formulation of an algorithm. 
   
   Our website addresses this by ensuring that individuals who are attempting a programming challenge without a predefined algorithm. As the person writes or pastes code when he/she is solving the challenge, the website generates a pictorial representation of the algorithm. 

   This visual aid enhances the user's understanding of their coding process.</p>
   <p>Furthermore, we are open to developing an AI model that, upon detecting a user's recurring syntax errors in the code, learns to identify and highlights them. This ensures that the user directs their attention or concentration towards refining that specific piece of syntax.
</p></p>
                    </div>
                    <div className="col-lg-6 text-lg-end">
                        <img src={`${process.env.PUBLIC_URL}/assets/images/paw.png`} alt="" className="d-none d-lg-inline" />
                    </div>
                </div>
            </div>
        );
    }
}
