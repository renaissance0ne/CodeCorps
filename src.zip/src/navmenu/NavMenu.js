import React, { Component } from 'react';
import { Container, Navbar, NavbarBrand, Nav, NavItem, NavLink, Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import { Link } from 'react-router-dom';
import './NavMenu.css';
import 'font-awesome/css/font-awesome.min.css';

export class NavMenu extends Component {
    static displayName = NavMenu.name;

    constructor(props) {
        super(props);

        this.toggleNavbar = this.toggleNavbar.bind(this);
        this.toggleDropdown = this.toggleDropdown.bind(this);
        this.state = {
            collapsed: true,
            dropdownOpen: false,
        };
    }

    toggleNavbar() {
        this.setState({
            collapsed: !this.state.collapsed
        });
    }

    toggleDropdown() {
        this.setState(prevState => ({
            dropdownOpen: !prevState.dropdownOpen
        }));
    }

    render() {
        return (
            <header>
                <Navbar className="navbar-expand-sm navbar-toggleable-sm ng-white border-bottom box-shadow mb-3 tbackColor" light>
                    <Container className="tContainer">
                        <NavbarBrand><b>CODECORPS</b></NavbarBrand>
                        <Nav className="mr-auto" navbar>
                            <NavItem className="tliststyle">
                                <NavLink tag={Link} className="text-dark" to="/home"> <i className="fa fa-fw fa-home"></i> Home</NavLink>
                            </NavItem>
                            <NavItem className="tliststyle">
                                <NavLink tag={Link} className="text-dark" to="/ABOUT"> <i className="fa fa-pencil-square-o"></i> ABOUT</NavLink>
                            </NavItem>
                            <Dropdown nav isOpen={this.state.dropdownOpen} toggle={this.toggleDropdown}>
                                <DropdownToggle nav caret className="text-dark">
                                    <i className="fa fa-certificate"></i> COURSE
                                </DropdownToggle>
                                <DropdownMenu>
                                    <DropdownItem tag={Link} to="/COURSES">Course 1</DropdownItem>
                                    <DropdownItem tag={Link} to="/COURSES">Course 2</DropdownItem>
                                    <DropdownItem tag={Link} to="/COURSES">Course 3</DropdownItem>
                                    
                                </DropdownMenu>
                            </Dropdown>
                            <NavItem className="tliststyle">
                                <NavLink tag={Link} className="text-dark" to="/LEADERBOARDS"> <i className="fa fa-pencil-square-o"></i> LEADERBOARDS</NavLink>
                            </NavItem>
                        </Nav>
                        <Nav className="ms-auto" navbar>
                            <NavItem className="tliststyle">
                                <NavLink tag={Link} className="text-dark" to="/logout"> <i className="fa fa-sign-out"></i> Logout</NavLink>
                            </NavItem>
                        </Nav>
                    </Container>
                </Navbar>
            </header>
        );
    }
}
