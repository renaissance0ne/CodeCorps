import React, { Component } from 'react';

export class COURSES extends Component {
    render() {
        const containerStyle = {
            backgroundColor: '#CBC3E3', 
        };

        return (
            <div style={containerStyle}>
                <h2>COURSES</h2>
                <div className="row">
                    <div className="col-lg-6">
                    <p class="lead">Introducing "CodeCorps Academy" – your go-to destination for a purrfect programming education! 🐾</p>

<h2>🔍 Course Catalog:</h2>

<ol>
  <li>
    <h3>Paws-on Coding 101: Introduction to Programming</h3>
    <ul>
      <li>Dive into the basics of coding with a feline twist.</li>
      <li>Learn the fundamentals through interactive cat-themed exercises.</li>
    </ul>
  </li>

  <li>
    <h3>Whisker Wizardry: Advanced Algorithms</h3>
    <ul>
      <li>Sharpen your algorithmic skills with challenges inspired by our clever CodeCats.</li>
      <li>Explore intricate problem-solving with a touch of cat charm.</li>
    </ul>
  </li>

  <li>
    <h3>Meowchine Learning Mastery</h3>
    <ul>
      <li>Unleash the power of AI and Machine Learning with our expert-led courses.</li>
      <li>From supervised learning to neural networks, become a true Meowchine Learning enthusiast.</li>
    </ul>
  </li>

  <li>
    <h3>Git & Claw: Version Control Essentials</h3>
    <ul>
      <li>Master Git for seamless collaboration, just like our CodeCats collaborate in the coding kingdom.</li>
      <li>Navigate branches and commits with the agility of a coding cat.</li>
    </ul>
  </li>

  <li>
    <h3>Cuddly Code Collaboration: GitHub Practices</h3>
    <ul>
      <li>Learn to collaborate effectively using GitHub, where CodeCats come together to create tech wonders.</li>
      <li>Contribute to open-source projects and build a strong coding community.</li>
    </ul>
  </li>

  <li>
    <h3>Feline-Friendly Web Development</h3>
    <ul>
      <li>Create visually stunning websites with HTML, CSS, and JavaScript.</li>
      <li>Design with a cat's aesthetic in mind for that extra flair.</li>
    </ul>
  </li>

  <li>
    <h3>Cat-a-thon Challenges</h3>
    <ul>
      <li>Participate in our CodeCats-exclusive coding challenges.</li>
      <li>Test your skills, earn badges, and climb the leaderboard to become the top CodeCat.</li>
    </ul>
  </li>
</ol>

<h2>🎓 Special Features:</h2>

<ul>
  <li>
    <h3>Catnip Lounge: Networking and Collaboration</h3>
    <ul>
      <li>Connect with fellow CodeCats, share experiences, and collaborate on projects in our virtual Catnip Lounge.</li>
    </ul>
  </li>

  <li>
    <h3>Miaowsterclasses: Expert-Led Sessions</h3>
    <ul>
      <li>Attend live sessions hosted by industry experts and seasoned CodeCats.</li>
      <li>Gain insights and advice on mastering the art of programming.</li>
    </ul>
  </li>
</ul>

<p>Embark on your coding journey with CodeCats Academy – where curiosity meets coding and every lesson is a step closer to becoming a programming maestro! 🚀🐱</p>

                    </div>
                    <div className="col-lg-6 text-lg-end">
                        <img src={`${process.env.PUBLIC_URL}/assets/images/paw.png`} alt="" className="d-none d-lg-inline" />
                    </div>
                </div>
            </div>
        );
    }
}

export default COURSES;
