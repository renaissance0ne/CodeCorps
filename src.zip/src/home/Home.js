import React, { Component } from 'react';

export class Home extends Component {
    static displayName = Home.name;

    render() {
        return (
           <div>
                        <h6 style={{ fontSize: '1.5rem' }} className="text-center mt-3">
                            CODE<span>/</span>TODAY,
                            CONQUER<span>/</span>TOMORROW;
                        </h6>
                    
                        <div className="text-center mt-3" style={{ height: '100%' }}>
                    <img
                        src={`${process.env.PUBLIC_URL}/assets/images/catimage.JPEG`}
                        alt="logo"
                        style={{ height: '540', width: 'auto' }} 
                    />
                </div>
                </div>
           
        );
    }
}
