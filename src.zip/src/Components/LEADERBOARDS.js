import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js';
import $ from 'jquery';

function Skill() {
  const staticSkills = [
    {
      skillId: 1,
      skillCode: 'S001',
      skillName: 'Programming',
      createdBy: 'Vallabh',
      createdDate: '2023-01-01',
    },
    {
      skillId: 2,
      skillCode: 'S002',
      skillName: 'Web Development',
      createdBy: 'Adithya',
      createdDate: '2023-01-02',
    },
    {
      skillId: 3,
      skillCode: 'S003',
      skillName: 'Data Science',
      createdBy: 'Varshath',
      createdDate: '2023-01-03',
    },

    {
      skillId: 4,
      skillCode: 'S004',
      skillName: 'AI-ML',
      createdBy: 'Rajesh',
      createdDate: '2023-01-03',
    },

    {
      skillId: 5,
      skillCode: 'S005',
      skillName: 'Cyber Security',
      createdBy: 'Mohith',
      createdDate: '2023-01-03',
    },
  ];

  $(document).ready(function () {
    $('#example').DataTable();
  });

  return (
    <div className="container">
      <h2>LEADERBOARDS</h2>
      <table id="example" className="display">
        <thead>
          <tr>
            <th>SkillId</th>
            <th>SkillCode</th>
            <th>SkillName</th>
            <th>CreatedBy</th>
            <th>CreatedDate</th>
          </tr>
        </thead>
        <tbody>
          {staticSkills.map((skill) => (
            <tr key={skill.skillId}>
              <td>{skill.skillId}</td>
              <td>{skill.skillCode}</td>
              <td>{skill.skillName}</td>
              <td>{skill.createdBy}</td>
              <td>{skill.createdDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Skill;
