
import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';

function Login({ setIsAuthenticated }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const loginstatusmsg = document.querySelector('.loginstatusmsg'); 
  const navigate = useNavigate(); 

  // Validation function
  function handleSubmit(event) {
    var i = 0;
    var UsernameMsg = document.querySelector('.Usernameerrormsg');
    if (email.trim() === "") {
      UsernameMsg.innerHTML = "User Name is required";
      i = 1;
    } else {
      UsernameMsg.innerHTML = "";
    } 
    var PasswordMsg = document.querySelector('.passworderrormsg');
    if (password.trim() === "") {
      PasswordMsg.innerHTML = "Password is required";
      i = 1;
    } else {
      PasswordMsg.innerHTML = "";
    } 
    if (i === 1) {
      event.preventDefault();
      return false;
    } else {
      // Simulate login without API call
      if (email === "1" && password === "1") {
        setIsAuthenticated(true);
        navigate('/home');
      } else {
        loginstatusmsg.innerHTML = "Invalid username or password";
      }
    }
  }

  return (
    <div className="login-container">
      <div style={{ display: "flex", justifyContent: "center" }}>
        {/* <img
          className="photo"
          src={`${process.env.PUBLIC_URL}/assets/images/logo231.png`}
          alt="logo"
          height="70"
        /> */}
      </div> 
      <h4>Welcome Back !</h4>
      <p className="login-status"><span className="loginstatusmsg"></span></p>
      <div>
        <div>
          <label>User Name:</label>
          <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} />
          <span className="Usernameerrormsg text-danger"></span>
        </div>
      </div>
      <div>
        <div>
          <label>Password:</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <span className="passworderrormsg text-danger"></span>
        </div>
      </div>
      <div>
        <button onClick={handleSubmit} id="mySubmitButton">Login</button>
      </div>
    </div>
  );
}

export default Login;

